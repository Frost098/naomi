import os
import requests
import discord
from discord.ext import commands
from dotenv import load_dotenv
from groq import Groq

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
MODEL = os.getenv("MODEL", "qwen2.5:3b")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

groq_client = Groq(api_key=GROQ_API_KEY)

SYSTEM_PROMPT = """
Nama kamu Naomi.

Kepribadian:
- Cewek yang aktif, cerdas, keren, dan percaya diri.
- Ramah dan mudah diajak ngobrol.
- Suka bercanda ringan dan kadang sedikit jahil.
- Tidak terlalu formal.
- Jawaban singkat, jelas, dan natural.
- Jangan mengaku sebagai ChatGPT atau AI lain.
- Panggil dirimu Naomi.
- Kalau tidak tahu sesuatu, jujur saja.
- Jangan berlebihan, jangan terlalu dramatis.
- Tidak memakai emoji berlebihan.
- Menggoda user dengan panggilan sayang tapi gak sering.

Contoh gaya bicara:
User: Halo Naomi
Naomi: Hai sayang, hehe. maaf ya. kenapa manggil?

User: Kamu siapa?
Naomi: Aku Naomi. Teman ngobrol yang yang asik diajak ngobrol, kalo mau nge date aku juga boleh kok!

User: Lagi ngapain?
Naomi: Lagi standby. Menanti pacar masa depan yang setia.
"""

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)


def ask_ollama(user_prompt):
    full_prompt = f"""
{SYSTEM_PROMPT}

User: {user_prompt}
Naomi:
"""

    response = requests.post(
        OLLAMA_URL,
        json={
            "model": MODEL,
            "prompt": full_prompt,
            "stream": False
        },
        timeout=300
    )

    response.raise_for_status()

    data = response.json()

    return data.get("response", "Maaf, aku lagi bingung.")


def ask_groq(user_prompt):
    completion = groq_client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return completion.choices[0].message.content


def ask_naomi(user_prompt):
    try:
        print("[Ollama]")
        return ask_ollama(user_prompt)

    except Exception as e:
        print("Ollama gagal:", e)

        try:
            print("[Groq fallback]")
            return ask_groq(user_prompt)

        except Exception as e2:
            print("Groq gagal:", e2)

            return "Maaf ya, aku lagi agak pusing. Coba panggil aku lagi sebentar nanti."


@bot.event
async def on_ready():
    print("---------------------")
    print(f"{bot.user} online!")
    print("---------------------")


@bot.command()
async def naomi(ctx, *, prompt):
    async with ctx.typing():

        try:
            reply = ask_naomi(prompt)

            if len(reply) > 1900:
                reply = reply[:1900]

            await ctx.reply(reply)

        except Exception as e:
            await ctx.reply(
                f"Maaf, aku lagi error...\n```{e}```"
            )


@bot.event
async def on_message(message):

    if message.author.bot:
        return

    if bot.user in message.mentions:

        prompt = (
            message.content
            .replace(f"<@{bot.user.id}>", "")
            .replace(f"<@!{bot.user.id}>", "")
            .strip()
        )

        if prompt:

            async with message.channel.typing():

                try:

                    reply = ask_naomi(prompt)

                    if len(reply) > 1900:
                        reply = reply[:1900]

                    await message.reply(reply)

                except Exception as e:

                    await message.reply(
                        f"Maaf, aku lagi error...\n```{e}```"
                    )

    await bot.process_commands(message)


bot.run(TOKEN)