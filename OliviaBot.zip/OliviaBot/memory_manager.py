import json
import os
import random

MEMORY_FILE = "memory.json"

# ======================
# LOAD MEMORY
# ======================

if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        memories = json.load(f)
else:
    memories = {}

# ======================
# DEFAULT DATA
# ======================

DEFAULT_NICKNAMES = [
    "bang",
    "kak",
    "bos",
    "bocil",
    "manusia random",
    "ketua mie ayam",
    "si tukang begadang",
    "wibu"
]


def create_user():
    return {
        "nickname": random.choice(DEFAULT_NICKNAMES),

        # relationship
        "affection": 0,

        # mood saat ini
        "mood": "normal",

        # riwayat chat terakhir
        "history": [],

        # memori jangka panjang
        "facts": {
            "favorite_food": None,
            "favorite_game": None,
            "favorite_anime": None,
            "favorite_character": None,
            "sleep_habit": None,
            "hobby": None
        },

        # waktu terakhir ngobrol
        "last_seen": None
    }


# ======================
# USER DATA
# ======================

def get_user_data(user_id):

    if user_id not in memories:
        memories[user_id] = create_user()

    return memories[user_id]


# ======================
# HISTORY
# ======================

def add_history(user_id, text):

    user = get_user_data(user_id)

    user["history"].append(text)

    # simpan 20 chat terakhir saja
    user["history"] = user["history"][-20:]


# ======================
# FACTS
# ======================

def set_fact(user_id, key, value):

    user = get_user_data(user_id)

    if key in user["facts"]:
        user["facts"][key] = value


def get_fact(user_id, key):

    user = get_user_data(user_id)

    return user["facts"].get(key)


# ======================
# NICKNAME
# ======================

def set_nickname(user_id, nickname):

    user = get_user_data(user_id)

    user["nickname"] = nickname


# ======================
# SAVE
# ======================

def save_memory():

    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(
            memories,
            f,
            ensure_ascii=False,
            indent=2
        )


# ======================
# RESET USER MEMORY
# ======================

def reset_user(user_id):

    memories[user_id] = create_user()

    save_memory()