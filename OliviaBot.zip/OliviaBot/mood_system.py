import random
import time

def get_mood(user_data):

    current_mood = user_data.get("mood", "normal")

    # Waktu sekarang
    hour = time.localtime().tm_hour

    # Kadang ganti mood sedikit
    if random.random() < 0.15:

        moods = [
            "normal",
            "happy",
            "playful",
            "sleepy",
            "lazy"
        ]

        current_mood = random.choice(moods)

    # Malam lebih ngantuk
    if hour >= 23 or hour <= 4:
        current_mood = random.choice([
            "sleepy",
            "lazy",
            current_mood
        ])

    user_data["mood"] = current_mood

    return current_mood


def get_mood_description(mood):

    descriptions = {

        "normal":
        """
Santai dan natural.
""",

        "happy":
        """
Sedang senang, lebih ceria, lebih sering bercanda.
""",

        "playful":
        """
Sedikit jahil, suka menggoda dan bercanda ringan.
""",

        "sleepy":
        """
Agak ngantuk, lebih kalem dan kadang bilang ingin tidur.
""",

        "lazy":
        """
Sedikit malas dan suka bercanda tentang kemalasan.
"""
    }

    return descriptions.get(
        mood,
        descriptions["normal"]
    )