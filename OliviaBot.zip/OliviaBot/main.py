import os
import time
import discord
from discord.ext import commands
from dotenv import load_dotenv

from google import genai
from groq import Groq

from memory_manager import (
    get_user_data,
    add_history,
    save_memory
)

from mood_system import get_mood

from relationship import (
    update_relationship,
    get_relationship_stage,
    maybe_change_nickname,
    get_greeting
)

from personalities import build_system_prompt

from sus_system import set_sus_level


# =====================
# LOAD ENV
# =====================

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

gemini_client = genai.Client(api_key=GEMINI_API_KEY)
groq_client = Groq(api_key=GROQ_API_KEY)

cooldowns = {}


# =====================
# DISCORD BOT
# =====================

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)


# =====================
# READY
# =====================

@bot.event
async def on_ready():
    print(f"{bot.user} online")


# =====================
# AI ROUTER (GEMINI → GROQ)
# =====================

def ask_ai(prompt: str, system_prompt: str):

    # =====================
    # GEMINI (PRIMARY)
    # =====================
    try:
        response = gemini_client.models.generate_content(
            model="gemini-2.5-flash-lite",
            contents=f"{system_prompt}\n\nUser: {prompt}"
        )
        return response.text

    except Exception as e:
        err = str(e)

        # fallback kalau overload
        if "429" in err or "503" in err or "UNAVAILABLE" in err:
            pass
        else:
            print("Gemini error:", err)
            return "ih error di otak utama 😭"

    # =====================
    # GROQ (FALLBACK)
    # =====================
    try:
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content

    except Exception as e:
        print("Groq error:", e)
        return "server lagi tumbang semua 😭 coba lagi nanti"


# =====================
# MESSAGE HANDLER
# =====================

@bot.event
async def on_message(message):

    if message.author.bot:
        return

    user_id = str(message.author.id)
    user_data = get_user_data(user_id)

    # =====================
    # SUS COMMAND
    # =====================
    if message.content.startswith("!sus"):

        if message.author.guild_permissions.administrator:

            try:
                level = int(message.content.split(" ")[1])
                set_sus_level(level)

                await message.reply(f"Sus level di-set ke {level}")

            except:
                await message.reply("pakai: !sus 0-3")

        else:
            await message.reply("lu bukan admin 😒")

        return

    # =====================
    # ONLY RESPOND IF MENTIONED
    # =====================
    if bot.user not in message.mentions:
        return

    # =====================
    # COOLDOWN
    # =====================
    now = time.time()

    if user_id in cooldowns:
        if now - cooldowns[user_id] < 5:
            await message.reply("ih sabar napa 😭")
            return

    cooldowns[user_id] = now

    # =====================
    # EXTRACT PROMPT
    # =====================
    prompt = (
        message.content
        .replace(f"<@{bot.user.id}>", "")
        .replace(f"<@!{bot.user.id}>", "")
        .strip()
    )

    if prompt == "":
        await message.reply(get_greeting(user_data))
        return

    # =====================
    # UPDATE SYSTEM STATE
    # =====================
    update_relationship(user_data)
    maybe_change_nickname(user_data)

    mood = get_mood(user_data)
    relationship_stage = get_relationship_stage(user_data)

    system_prompt = build_system_prompt(
        user_data,
        mood,
        relationship_stage
    )

    history_text = "\n".join(
        user_data["history"][-20:]
    )

    full_prompt = f"""
{system_prompt}

Riwayat percakapan:
{history_text}

User: {prompt}
Olivia:
"""

    try:

        async with message.channel.typing():

            answer = ask_ai(prompt, full_prompt)

        # =====================
        # SAVE MEMORY
        # =====================
        add_history(user_id, f'{user_data["nickname"]}: {prompt}')
        add_history(user_id, f'Olivia: {answer}')
        save_memory()

        # limit discord message
        if len(answer) > 1900:
            answer = answer[:1900]

        await message.reply(answer)

    except Exception as e:

        print("Fatal error:", e)

        await message.reply("olivia error total 😭")


# =====================
# RUN BOT
# =====================

bot.run(TOKEN)