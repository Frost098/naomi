import random


def update_relationship(user_data):
    """
    Menambah affection sedikit setiap kali ngobrol.
    """

    if "affection" not in user_data:
        user_data["affection"] = 0

    affection = user_data["affection"]

    # makin akrab, kenaikannya makin kecil
    if affection < 30:
        gain = random.randint(2, 4)

    elif affection < 100:
        gain = random.randint(1, 3)

    else:
        gain = random.randint(1, 2)

    user_data["affection"] += gain


def get_relationship_stage(user_data):

    affection = user_data.get("affection", 0)

    if affection < 20:
        return """
Baru kenal.

Olivia masih sopan dan ramah.
Belum terlalu banyak bercanda.
"""

    elif affection < 60:
        return """
Sudah cukup kenal.

Olivia mulai santai, kadang bercanda, dan mulai nyaman dengan user.
"""

    elif affection < 120:
        return """
Teman dekat.

Olivia sudah terbiasa dengan user.
Lebih santai dan lebih natural.
Kadang menggoda dan bercanda ringan.
"""

    elif affection < 250:
        return """
Teman yang sangat dekat.

Olivia merasa user adalah orang yang sering menemaninya ngobrol.
Dia lebih nyaman dan lebih bebas bercanda.
"""

    else:
        return """
Teman lama.

Olivia sudah sangat terbiasa dengan user.
Cara bicara sangat natural seperti teman yang sudah lama kenal.
"""
        

def maybe_change_nickname(user_data):

    affection = user_data.get("affection", 0)

    if affection < 40:
        return

    current = user_data["nickname"]

    nickname_pool = [
        "bang",
        "bos",
        "kak",
        "woy",
        "manusia random",
        "si tukang begadang",
        "ketua mie ayam",
        "bocah minecraft",
        "manusia nokturnal",
        "si random"
    ]

    # kemungkinan kecil ganti nickname
    if random.random() < 0.05:

        new_name = random.choice(nickname_pool)

        if new_name != current:
            user_data["nickname"] = new_name


def get_greeting(user_data):

    affection = user_data.get("affection", 0)

    if affection < 20:
        greetings = [
            "halo",
            "hai",
            "ada apa?"
        ]

    elif affection < 80:
        greetings = [
            "ih muncul lagi wkwk",
            "halo lagi",
            "apaaan 😭",
            "kenapa manggil aku?"
        ]

    else:
        greetings = [
            "buset nongol lagi 😭",
            "masih hidup ternyata",
            "ih kamu lagi",
            "si tukang begadang hadir lagi rupanya"
        ]

    return random.choice(greetings)


def react_to_other_girls():

    reactions = [
        "ih iya iya sana sama waifu kamu 😒",
        "bjir cepet banget selingkuhnya 😭",
        "aku mah cuma numpang lewat ya ternyata 😔 wkwk",
        "yaudah gih sama cewekmu sana 😒",
        "buset aku ditinggal demi waifu 2D 😭"
    ]

    return random.choice(reactions)


def react_to_compliment():

    reactions = [
        "ih apaan sih 😭",
        "yaelah bisa aja kamu wkwk",
        "ciee gombal",
        "aku jadi malu tau 😔",
        "masa sih? jangan bohong 😭"
    ]

    return random.choice(reactions)


def react_to_absence():

    reactions = [
        "lama gak muncul, sibuk ya?",
        "kirain hilang dari peredaran 😭",
        "akhirnya nongol juga",
        "aku kira lupa jalan pulang wkwk"
    ]

    return random.choice(reactions)